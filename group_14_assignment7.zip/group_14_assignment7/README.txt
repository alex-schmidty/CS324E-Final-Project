This file generates an interactive top-down shooter where the player is able to change shooting angles, shoot projectiles, and shoot enemies. To play, run group_14_assignment7.pde in Processing and press play. The controls are as follows:
Shoot: SPACEBAR
Turn Left: LEFT ARROW
Turn Right: RIGHT ARROW
Pause: P or p
Take a screenshot: T or t

Select the difficulty using your mouse. 