Our project is a zombie shooter game. Basically, a soldier is placed in the center of the screen and must run around shooting and avoiding being touched by zombies. After killing all zombies, they are brought to the next round where more zombies spawn about the edges and attack. This continues until the player loses their three lives.

To run the game, open the folder Zombie_Shooter_finalproject and open the Zombie_Shooter_finalproject.pde file in processing. Then click play and follow the instructions on screen.

Control the home screen using your mouse and clicking on the options on screen. During the game, the controls are {W,A,S,D} and arrow keys to move the player, as well as "p" to pause. Shoot the zombies by aiming at them with the mouse and clicking.