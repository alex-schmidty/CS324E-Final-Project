Requirements:
2) three rules include: 
	- moving left and right
	- shooting bullets
	*- Pause functionality
		- needs to be implemented with timer class
3) four kepboard inputs:
	- left/a/A to move left
	- right/d/D to move right
	- spacebar to shoot bullets
	*- P/p to pause 
		- needs to be implemented with timer class
4) *Implement "waves" of enemies 
	- once enemy class is created, there will be levels of enemies of different sizes and number of enemies spawned
	- need to write "Round #" at the top/bottom of screen
	
5) *Need to implement GUI as start/loading screen
	- Starting screen will allow player to click to start
	- can offer a choice to skip ahead to later waves (start at wave 1, 5, or 10)
	- Hold information for high score (let's use a float variable that holds the highest wave reached in one run of program)
6)* Win/Defeat
	- If an enemy touches the player, the screen goes dark and says "Game Over" before returning to start / loading screen
	- If a player kills all enemies in round 15, screen goes black and says "You Won!", then returns to main screen
